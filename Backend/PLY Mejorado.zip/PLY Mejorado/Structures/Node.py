class Node:
    def __init__(self):
        self.type = ""
        self.Carnet = ""
        self.DPI = ""
        self.Nombre = ""
        self.Carrera = ""
        self.Password = ""
        self.Creditos = 0
        self.Edad = 0
        self.Correo = ""
        self.Descripcion = ""
        self.Materia = ""
        self.Fecha = ""
        self.Hora = ""
        self.Estado = ""

    def clean_values(self):
        self.type = ""
        self.Carnet = ""
        self.DPI = ""
        self.Nombre = ""
        self.Carrera = ""
        self.Password = ""
        self.Creditos = 0
        self.Edad = 0
        self.Correo = ""
        self.Descripcion = ""
        self.Materia = ""
        self.Fecha = ""
        self.Hora = ""
        self.Estado = ""
